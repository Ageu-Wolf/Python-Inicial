var nome = 'Thiago';
var profissao = 'Engenheiro';
var valor = 'R$20';
var banco = 'Pic Pay';
//alert('Olá '+ nome +' seja bem-vindo!')


//alert(`Olá ${profissao} ${nome} seja bem-vindo(a)!`);

//alert(`Pix de ${nome} no valor de ${valor} enviado pelo ${banco}`)

//  LISTAS  //
var listaFrutas = ['maçã', 'uva', 'melancia', 'limão'];
//alert(listaFrutas[2]);

//  WHILE  //
var indice = 0;

/*while (indice < listaFrutas.length){
    alert(listaFrutas[indice]);    
    indice++;
}*/

 // FOR
/*for (item of listaFrutas){
    alert (item);
    item++
}*/

// IF
var idade = 40;
var temCNH = true;

/*if (idade >=18 && temCNH){ -- "==" comparador "=" atribuidor de elemento "!=" diferente
    alert('Maior de idade, pode dirigir');
}else{
    alert('Menor de idade, não pode dirigir');
}*/

//var a = 100;
//var b = '100';

/*if (a == b){
    alert('a é igual a b');
}else{
    alert('a e b são diferentes');
}*/

/*function soma(a, b){
    var resultado = a + b;
    //alert(resultado);uma maneira de mostrar o resultado
    return resultado;
}

s = soma(100, 20);
alert(s);*/

function meClicaram(){
    //alert('O usuario me clicou!')
    console.log('O usuario me clicou!');
}
function botao(){
    console.log('Botão2 foi clicado');
}

function tornarEscuro(){
    var corpo = document.getElementById('corpo');
    corpo.style.background = '#000000';
    corpo.style.color = '#FFFFFF';
    
}
function tornarClaro(){
    var corpo = document.getElementById('corpo')
    corpo.style.background = '#FFFFFF'
    corpo.style.color = '#000000'

}
function alterarModoGenerico(modo){
    if(modo == 'claro'){
        var corpo = document.getElementById('corpo');
        corpo.style.background = '#FFFFFF';
        corpo.style.color = '#000000';
    }else if(modo == 'escuro'){
        var corpo = document.getElementById('corpo');
        corpo.style.background = '#000000';
        corpo.style.color = '#FFFFFF';
    }else{
        alert('Modo inválido');
    }
}
function teletransportar(){
    var origem = document.getElementById('origem');
    var destino = document.getElementById('destino');
    destino.value = origem.value
    origem.value = '';
}
function portar(){
    var daqui = document.getElementById('daqui');
    alert(daqui.value)
}
















