telefone = imput('telefone')
===
   012345678910
   5599648184
===

ddd = telefone{0:2}
tel1 = telefone{2:7}
tel2 = telefone(7:11)

print(f'{ddd}*{tel1}*(tel2}')




