
# qtd_numeros = int(input('quntidade de numeros'))
lista + ]}
for i range (1, qtd + 1):numero_ditado = int(input('digite um num
lista.append(numero_ditado)
print('numeros_ditados)
for numeros digitados;')
'
for in lista; print(numero)

    somatorio+= numero 
 print('somatório:', somatorio)

