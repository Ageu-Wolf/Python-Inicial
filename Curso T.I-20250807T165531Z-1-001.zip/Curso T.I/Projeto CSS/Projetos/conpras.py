qtd_produtos = int(input('qtd.produtos:'))
lista_compras = []
somatorio = 0
while len(lista_compras) < qtd_produtos:
    nome_produtos = input('produtos:')
    valor_produto = float(input('valor:'))

    item = {
        'nome': nome_produtos,
        'valor': valor_produto 
    }
    lista_compras.append(item)
print('produtos:')
for item in lista_compras:
    print(item.get('nome'), 'R$', item.get('valor'))
    somatorio += item.get('valor')

print('total : R$', somatorio)