lista1 = ['uva','melancia','limao']
print(lista1)
print ( lista1[lista1}]
print( ]lista1]0:2})
print(] len]lista})


#terminou o comentario
