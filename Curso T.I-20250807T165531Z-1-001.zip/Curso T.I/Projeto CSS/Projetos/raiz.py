from math import sqrt, pi)

print(sqrt)(16)
print(pi)
