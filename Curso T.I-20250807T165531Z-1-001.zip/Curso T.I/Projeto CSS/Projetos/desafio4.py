from datetime import datetime, date

lista = []

for i in range(1,6):
    nome = input('digite seu nome:')
    print('                           ')
    data_nasc = input('digite sua data de nascimento:')
    print('                           ')
    data_nasc = datetime.strptime(data_nasc, '%d/%m/%Y').date()

    idade = (date.today() - data_nasc).days / 365

    if idade >=30 and idade <=35:
        print('Voce', nome, 'podera ser vacinado')
        lista.append(nome)
        print('                        ')
    else:
        print('voce', nome, 'nao pode ser vacinado, pois nao tem a idade certa')
        print('                                    ')
print('lista de pessoas que poderam ser vacinadas!!')

for nome_lista in lista:
    print(nome_lista,'voce podera ser vacinado')
