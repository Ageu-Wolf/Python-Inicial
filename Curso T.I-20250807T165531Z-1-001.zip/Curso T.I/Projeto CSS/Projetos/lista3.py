chamada_ordenada = ['Ageu', 'Manuela', 'Murilo', 'Sara']

for aluno in chamada_ordenada:
    print(aluno)