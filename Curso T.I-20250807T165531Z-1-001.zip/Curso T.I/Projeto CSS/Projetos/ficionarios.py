
serie1 = {nome:the[}
serie2= (nome:two)

videoteca.append(serie1)
videoteca.append(serie2)

print(videoteca{0[.get('nome{)}

