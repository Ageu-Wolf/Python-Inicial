var1 = 'gerson'
var2 = 100

var3 = 'texte'
print (var1, var2, var3, 'continuacao')
texto1 = 'interpoland %s' % var1
print(texto1)
texto2 = 'interpolando 2 %s ou %s' %(var1, var3)
print(texto2)
texto3 = 'interpolando 3 %s e %s'%(var3, var2)
print(texto3)
texto4 = 'interpolando 4 {a} e {b}'.format(a=var1, b=var2)
print(texto4)
texto5 = 'interpolando 4 {} e {}'.format(var1, var2)
print(texto5)

texto6 = f'interpolando {var1} e {var2} e {var3}.'
print(texto6)

