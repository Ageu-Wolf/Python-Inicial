print('calcule imc')

peso = float(input('calcule o peso em '))
altura = float(input('calcule a altura'))

imc = peso / (altura * altura)


print('resultado do imc',imc)

if imc < 18.5:
    print('abaixo do peso')

elif imc >18.5 and imc <= 24.9:
    print ('pesp normal')
    