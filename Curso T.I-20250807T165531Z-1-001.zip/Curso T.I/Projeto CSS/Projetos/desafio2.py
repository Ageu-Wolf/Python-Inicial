from datetime import date, timedelta

print('========EMPRESA DSF=========')

nome_cliente = input('Digitar seu nome:')

numero_cllr = input('Digite seu telefone:')

produto = input('informe seu produto:')

defeito = input('informe o defeito:')

hoje = date.today()
dt_futura = hoje + timedelta(days=7)

dt_futura_string_br = dt_futura.strftime('%d/%m/%Y')

print('ola', nome_cliente, 'seu produto estara pronto apos 7 dias da entrega para o concerto, estara pronto na data', dt_futura_string_br )


