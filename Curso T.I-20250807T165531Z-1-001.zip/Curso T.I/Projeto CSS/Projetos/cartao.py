nome = input('nome:')
setor = input('setor:')
email = input('email:')
telefone=input('telefone:')
cargo=input('cargo')



print('rst turma top') 
print(nome)  
print('setor', setor, 'cargo', cargo)
print('email', email)
print('telefone:', telefone)