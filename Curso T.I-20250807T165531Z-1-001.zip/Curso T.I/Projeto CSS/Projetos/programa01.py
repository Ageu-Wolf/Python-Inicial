print('SEGUNDO DIA COMO PROGRAMADOR')

numero01 = 300

numero02 = 2 
resultado = numero01 ** numero02

print('O RESULTADO É:', resultado)