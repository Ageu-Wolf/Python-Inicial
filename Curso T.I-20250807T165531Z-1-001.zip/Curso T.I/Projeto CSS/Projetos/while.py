continuar == 'sim'



while continuar=='sim':


continuar = input('devo continuar...'). upper()

print('continuando...')
print('ufa1 finalmente parei1')
