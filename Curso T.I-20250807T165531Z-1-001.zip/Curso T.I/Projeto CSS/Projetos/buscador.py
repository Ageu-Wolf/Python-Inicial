palavras = ]}
qtd_palavras = int (input]'qqtd.palavras?')
format