lista_conpras.appendi(cerveja)
print_(lista_compras)


print( li)