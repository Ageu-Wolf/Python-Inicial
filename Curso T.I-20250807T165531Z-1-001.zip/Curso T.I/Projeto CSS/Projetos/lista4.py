lista5.py
ls=] 2, 8, 23}
for item= in ls;
numeros=[1,70,16,8]

ls.append('ultimo elemento')
print(2*item)


for n in numeros:
    print('o dobro de ', n, 'é')
    print(n*2)
