from operator import truediv


semaforo_verde= True


if semaforo_verde:
     print('carro continuar')
else:
    print('carro parar')
print ('final')


