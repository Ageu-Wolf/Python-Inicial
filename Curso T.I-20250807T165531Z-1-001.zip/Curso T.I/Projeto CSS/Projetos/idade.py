idade = int(input('informe a idade'))
print(A pessoa tem',idade, 'anos')
if idade >= 18:
print(Menor de idade')
Else:

    print('Menor de idade')
    