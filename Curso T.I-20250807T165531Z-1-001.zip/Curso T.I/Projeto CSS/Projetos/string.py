texto = 'este e o meu texto'
texto2= 'TEXTO '


print(texto.upper())
print(texto2.lower())
print(texto.title())

texto3= 'A Rita é minha namorada'
print(texto3)
print(texto3.replace('Rita',' joao').replace('minha' ,'meu').replace('A','O').replace('namorada','namorado'))
variavel= 'colorado'
tamanho=len(variavel ) 
print(tamanho)
