def mensagem_game_over():
    print(30*'*')
    print('Game over')
    print('tente novamente!')
    print(30*'*')
mensagem_game_over()
mensagem_game_over()
#funcoes
def ola(nome, idade):
    print(30*'*')
    print(f'ola {nome}')
    print(f'que legal, voce tem{idade} anos')
    print('como esta')
#programa principal
nome_usuario = 'anacleto'
ola(nome_usuario, 50)

def somar(num1, num2):
    return num1 + num2
resultado = somar(num1=10, num2=35)
print(resultado)
def subtrair(num1,num2):
    return num1 - num2
resultado = subtrair(500,300)
print(resultado)
