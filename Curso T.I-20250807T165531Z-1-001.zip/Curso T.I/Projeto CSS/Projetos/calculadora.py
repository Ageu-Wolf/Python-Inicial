import osfrom time import sleep
from menu import mostrar_menu, capturar_numeros
