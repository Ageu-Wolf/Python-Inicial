nome=input('informe o seu nome:')
print(nome.upper())
print('0 nome digitado possui',len(nome),'caracteres')
