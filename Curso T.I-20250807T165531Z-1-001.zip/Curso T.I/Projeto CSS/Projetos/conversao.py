
a=10
b-'casa'
c=a+int(b)

print(c)''''''''''''''''
