texto = 'Teste do Gerson'
print(texto)