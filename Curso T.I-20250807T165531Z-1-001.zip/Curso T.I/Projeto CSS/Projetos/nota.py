print('aplicativo boletin')
print(20*'_')
nome = input('nome do aluno:')
nota1 = float(input('nota 1:'))
nota2 = float(input('nota 2:'))
nota3 = float( input ('nota 3:'))
nota_final = (nota1 + nota2 + nota3) / 3 

print(nome.upper())
print('nota final;', nota_final )
if nota_final>= 7:
    print('Aprovado')
else:
    print('Reprovavado')

