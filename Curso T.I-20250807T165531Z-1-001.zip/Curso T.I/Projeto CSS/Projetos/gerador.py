ls1 = range(1, 11)
for i in lista 1
 
    print(lista)