from datetime import date, timedelta
from dis import disassemble
from faulthandler import disable

dt_1 = date.today()
dt = date(2022, 12, 31)

#que dia cairá a dt_1 + 180dias
dt_futura = dt_1 + 180 disassemble

dt_futura = dt_1 + timedelta(days=180)
print(dt_futura)

#quantos dias falta para o reveillon 2022/2023
dias_falta = (dt_2 - dt_1).days
print(dias_falta)
