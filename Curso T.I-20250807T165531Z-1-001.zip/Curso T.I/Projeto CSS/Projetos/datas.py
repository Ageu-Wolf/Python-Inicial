from calendar import day_abbr, month
from datetime import date, datetime

from datetime import date

data1 = date(1969, 6, 9)

print(data1)
print(data1.year)
print(data1.day)

print(data1.day)

hoje = date(2022,10,6)
hoje = date.today()
print(hoje)

idade = (hoje - data1).days/365

data2 = date(2023, 10, 7)
print(data2)
data2 = data2.replace(year=2028, month=2, day=13)

print(date)
date_hora = datetime(2022, 10, 7, 19, 41, 00)
agora = datetime.now()
print(agora)
agora = agora.replace(year=2030,
                      month=12, 
                      day=31,
                      hour=10, 
                      minute=20)
print(agora)

#data_hora_string_br = agora.strftime('%d/ %m/ %h:%m,%s')

#print(data_hora_string_br)
#datetime para string
dt_nasc   = date(1968, 6, 9)

data_string_br = agora.strftime('%d,%m,%y')
print(dt_nasc.strftime('%d/%m/%y'))

data_string = '9/6/1968' 

data_date = datetime.strptime(data_string, '%d/%m/%Y')
print(data_date)
data_a = date(2022, 2, 20)
dataB = date(2022, 3, 14)
print(data_a = data_b)
print(data_a> data_b)
print(data_a < data_b)

hoje = date.today()
dt_futura = timedelta(days=30)
print(hoje, dt_futura)



