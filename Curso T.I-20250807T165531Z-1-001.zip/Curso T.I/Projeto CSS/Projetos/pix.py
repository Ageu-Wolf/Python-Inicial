print('*******************************')
print('App Internet Banking')
print('Tranferencia via pix')
print('********************')
chave_pix = input(' Digite a chave Pix')
valor = input('Digite o valor')


print('ovalor R$', valor, 'foi tranferido para a chave',chave_pix)
