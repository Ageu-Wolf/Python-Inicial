


print('aplicativo de conversao de dolar')
print(30*'*')

cotacao=5.12
valor_dolar= float(input('informe o valor em dolar:'))


valor_real = cotacao * valor_dolar
print('cotacao do dolar: R$', cotacao)
print('valor do produto em dolar US$', valor_dolar)
print('valor do produto em real R$', valor_real)
