usuario = input('Digite o seu nome: ')
print('Olá', usuario)