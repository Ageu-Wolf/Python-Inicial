idade = int(input('Informe a idade:'))

print('A pessoa tem', idade, 'anos')

if idade >= 18:
    print('A pessoa é de maior')

else:
    print('menor de idade')