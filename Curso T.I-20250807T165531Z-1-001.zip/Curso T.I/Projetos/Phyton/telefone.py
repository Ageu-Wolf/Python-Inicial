
variavel = input('Seu numero de telefone:')

ddd =variavel[0:2]
num1 = variavel[2:7]
num2 = variavel[7:11]

telefone = f'({ddd}) {num1}-{num2}'
#Outra forma'print(f'({ddd}) {num1}-{num2}')
print(telefone)


