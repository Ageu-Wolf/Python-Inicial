a = 10
b = '5'

c = a+int(b)

print(c)