continuar = 'SIM'

while continuar == 'SIM' or continuar == 'TALVEZ':
    continuar = input('Devo continuar?').upper()
    print('Continuando...')

print('Ufa! Finalmente parei!')