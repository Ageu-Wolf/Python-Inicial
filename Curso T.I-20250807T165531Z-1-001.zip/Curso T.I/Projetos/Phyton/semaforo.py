semaforo_verde = 40 > 2

if semaforo_verde: 
    print('Carro continuar')
else:
    print('Carro parar')

print('Final')