from csv import list_dialects


lista_compras = []

lista_compras.append('Cerveja')
lista_compras.append('BIS')
lista_compras.append('Amendoin')
lista_compras.append('Leite')
lista_compras.append('Leite')

print(lista_compras)

print('a palavra leite aparece:',lista_compras.count('Leite'),'vezes')
print('a palavra leite aparece:',lista_compras.count('tomate'),'vezes')



