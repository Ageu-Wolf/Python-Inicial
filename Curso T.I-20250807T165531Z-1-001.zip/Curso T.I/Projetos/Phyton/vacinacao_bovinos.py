bovinos = [{'peso_kg': 362, 'tipo': 'Novilho Macho'},
 {'peso_kg': 332, 'tipo': 'Novilha Femea'},
 {'peso_kg': 210, 'tipo': 'Novilha Femea'},
 {'peso_kg': 188, 'tipo': 'Novilha Femea'},
 {'peso_kg': 318, 'tipo': 'Novilha Femea'},
 {'peso_kg': 229, 'tipo': 'Novilho Macho'},
 {'peso_kg': 274, 'tipo': 'Novilha Femea'},
 {'peso_kg': 338, 'tipo': 'Novilho Macho'},
 {'peso_kg': 382, 'tipo': 'Novilho Macho'},
 {'peso_kg': 412, 'tipo': 'Novilho Macho'},
 {'peso_kg': 116, 'tipo': 'Novilho Macho'},
 {'peso_kg': 108, 'tipo': 'Novilho Macho'},
 {'peso_kg': 298, 'tipo': 'Novilha Femea'},
 {'peso_kg': 106, 'tipo': 'Novilha Femea'},
 {'peso_kg': 344, 'tipo': 'Novilha Femea'},
 {'peso_kg': 280, 'tipo': 'Novilha Femea'},
 {'peso_kg': 241, 'tipo': 'Novilho Macho'},
 {'peso_kg': 215, 'tipo': 'Novilho Macho'},
 {'peso_kg': 258, 'tipo': 'Novilha Femea'},
 {'peso_kg': 190, 'tipo': 'Novilho Macho'},
 {'peso_kg': 138, 'tipo': 'Novilho Macho'},
 {'peso_kg': 159, 'tipo': 'Novilho Macho'},
 {'peso_kg': 445, 'tipo': 'Novilho Macho'},
 {'peso_kg': 375, 'tipo': 'Novilha Femea'},
 {'peso_kg': 462, 'tipo': 'Novilho Macho'},
 {'peso_kg': 397, 'tipo': 'Novilha Femea'},
 {'peso_kg': 146, 'tipo': 'Novilho Macho'},
 {'peso_kg': 376, 'tipo': 'Novilho Macho'},
 {'peso_kg': 234, 'tipo': 'Novilho Macho'},
 {'peso_kg': 276, 'tipo': 'Novilho Macho'},
 {'peso_kg': 168, 'tipo': 'Novilha Femea'},
 {'peso_kg': 452, 'tipo': 'Novilho Macho'},
 {'peso_kg': 232, 'tipo': 'Novilho Macho'},
 {'peso_kg': 148, 'tipo': 'Novilho Macho'},
 {'peso_kg': 404, 'tipo': 'Novilho Macho'},
 {'peso_kg': 479, 'tipo': 'Novilha Femea'},
 {'peso_kg': 340, 'tipo': 'Novilha Femea'},
 {'peso_kg': 118, 'tipo': 'Novilha Femea'},
 {'peso_kg': 450, 'tipo': 'Novilha Femea'},
 {'peso_kg': 417, 'tipo': 'Novilho Macho'},
 {'peso_kg': 234, 'tipo': 'Novilha Femea'},
 {'peso_kg': 133, 'tipo': 'Novilho Macho'},
 {'peso_kg': 195, 'tipo': 'Novilho Macho'},
 {'peso_kg': 129, 'tipo': 'Novilha Femea'},
 {'peso_kg': 180, 'tipo': 'Novilho Macho'},
 {'peso_kg': 273, 'tipo': 'Novilha Femea'},
 {'peso_kg': 118, 'tipo': 'Novilha Femea'},
 {'peso_kg': 407, 'tipo': 'Novilha Femea'},
 {'peso_kg': 414, 'tipo': 'Novilho Macho'},
 {'peso_kg': 358, 'tipo': 'Novilha Femea'},
 {'peso_kg': 367, 'tipo': 'Novilho Macho'},
 {'peso_kg': 475, 'tipo': 'Novilho Macho'},
 {'peso_kg': 159, 'tipo': 'Novilha Femea'},
 {'peso_kg': 196, 'tipo': 'Novilha Femea'},
 {'peso_kg': 168, 'tipo': 'Novilha Femea'},
 {'peso_kg': 239, 'tipo': 'Novilho Macho'},
 {'peso_kg': 413, 'tipo': 'Novilho Macho'},
 {'peso_kg': 409, 'tipo': 'Novilho Macho'},
 {'peso_kg': 142, 'tipo': 'Novilha Femea'},
 {'peso_kg': 204, 'tipo': 'Novilho Macho'},
 {'peso_kg': 101, 'tipo': 'Novilha Femea'},
 {'peso_kg': 159, 'tipo': 'Novilha Femea'},
 {'peso_kg': 150, 'tipo': 'Novilha Femea'},
 {'peso_kg': 252, 'tipo': 'Novilha Femea'},
 {'peso_kg': 184, 'tipo': 'Novilha Femea'},
 {'peso_kg': 207, 'tipo': 'Novilha Femea'},
 {'peso_kg': 164, 'tipo': 'Novilha Femea'},
 {'peso_kg': 424, 'tipo': 'Novilha Femea'},
 {'peso_kg': 363, 'tipo': 'Novilho Macho'},
 {'peso_kg': 175, 'tipo': 'Novilha Femea'},
 {'peso_kg': 134, 'tipo': 'Novilha Femea'},
 {'peso_kg': 109, 'tipo': 'Novilho Macho'},
 {'peso_kg': 292, 'tipo': 'Novilho Macho'},
 {'peso_kg': 108, 'tipo': 'Novilho Macho'},
 {'peso_kg': 418, 'tipo': 'Novilha Femea'},
 {'peso_kg': 245, 'tipo': 'Novilho Macho'},
 {'peso_kg': 209, 'tipo': 'Novilho Macho'},
 {'peso_kg': 228, 'tipo': 'Novilho Macho'},
 {'peso_kg': 170, 'tipo': 'Novilha Femea'},
 {'peso_kg': 336, 'tipo': 'Novilho Macho'},
 {'peso_kg': 241, 'tipo': 'Novilha Femea'},
 {'peso_kg': 139, 'tipo': 'Novilha Femea'},
 {'peso_kg': 185, 'tipo': 'Novilho Macho'},
 {'peso_kg': 235, 'tipo': 'Novilha Femea'},
 {'peso_kg': 307, 'tipo': 'Novilha Femea'},
 {'peso_kg': 173, 'tipo': 'Novilha Femea'},
 {'peso_kg': 131, 'tipo': 'Novilho Macho'},
 {'peso_kg': 122, 'tipo': 'Novilha Femea'},
 {'peso_kg': 228, 'tipo': 'Novilho Macho'},
 {'peso_kg': 166, 'tipo': 'Novilha Femea'},
 {'peso_kg': 357, 'tipo': 'Novilho Macho'},
 {'peso_kg': 444, 'tipo': 'Novilha Femea'},
 {'peso_kg': 119, 'tipo': 'Novilho Macho'},
 {'peso_kg': 177, 'tipo': 'Novilho Macho'},
 {'peso_kg': 400, 'tipo': 'Novilho Macho'},
 {'peso_kg': 426, 'tipo': 'Novilha Femea'},
 {'peso_kg': 205, 'tipo': 'Novilho Macho'},
 {'peso_kg': 314, 'tipo': 'Novilho Macho'},
 {'peso_kg': 221, 'tipo': 'Novilha Femea'},
 {'peso_kg': 328, 'tipo': 'Novilho Macho'}]

vacina_a = []
vacina_b = []


for bovino in bovinos:
    peso = bovino.get('peso_kg')
    if peso >= 300:
        vacina_a.append(bovino)
    else:
        vacina_b.append(bovino)

print(50*'=')
print('Bovinos vacina A')
for bovino in vacina_a:
    print(bovino.get('tipo'))
    print(bovino.get('peso_kg'), 'kg')
print(50*'=')

print(50*'=')
print('Bovinos vacina B:')
for bovino in vacina_b:
    print(bovino.get('tipo'))
    print(bovino.get('peso_kg'),'kg')



