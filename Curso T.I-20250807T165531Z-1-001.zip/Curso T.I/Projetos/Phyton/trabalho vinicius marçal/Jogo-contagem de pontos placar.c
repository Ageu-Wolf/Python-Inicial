//Ganhos dos jogos

#include <stdio.h>

int main()
{
    float percent_vit_snh,perc_vit_sal;
    int placar,time1=0,time2=0,rodar =1,jogos=0,dif_placar,maior_dif=0,menor_dif=99999,time1_vit,time2_vit;
    while(rodar==1){
    printf("Quantos pontos o Santa Maria Heat fez?");
    scanf("%d",&time1);
    printf("Quantos pontos os Santo Ângelo Lakers fizeram?");
    scanf("%d",&time2);
    if (time1>time2){
        dif_placar=time1-time2;
        time1_vit++;
        
    }else{
        dif_placar=time2-time1;
        time2_vit++;
    }
    if(dif_placar > maior_dif){
        maior_dif = dif_placar;
    }
    if(dif_placar < menor_dif){
        menor_dif=dif_placar;
    }
    jogos++;
    perc_vit_sal = (time2_vit*100)/jogos;
    percent_vit_snh = (time1_vit*100)/jogos;
    printf("Deseja registrar mais algum jogo? (digite 1 para acrescentar e 0 para encerrar");
    scanf("%d",&rodar);
    }
    printf("Foram feitos %d Jogos \n",jogos);
    printf("%f e %f \n",percent_vit_snh,perc_vit_sal);
    printf("A maior diferenca do placar foi de: %d \n",maior_dif);
    printf("A menor diferenca do placar foi de: %d \n",menor_dif);
    
    

    return 0;
}
