#include <stdio.h>

int main() {
    float numero;
    int num =1;

    printf("Digite um número real: ");
    scanf("%f", &numero);

    printf("Número multiplicado até 200:\n");
    for (int cont=1; cont <= 200; cont++){
        printf("%d=%.2f  ",cont, numero * cont);
        if (num == 10) {
            printf("\n");
            num = 0;
        }
        num++;
    }

    return 0;
}