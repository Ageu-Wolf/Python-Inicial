#include <stdio.h>
int main()
{
    int num=0,sq1,sq2,sq3,sq4,num_maior=0,num_menor=9999999;
    while(num>=0){
        
        printf("Digite um número: ");

        scanf("%d", &num);

        if(num<0){
            printf("Numero invalido!!\n");
            break;

        }

        if((num>=0) && (num<=25)){

            sq1++;

        }if ((num>=26) && (num<=50)){

            sq2++;

        }if ((num>=51) && (num<=75)){

            sq3++;

        }if ((num>=76) && (num<=100)){

            sq4++;

        }
        if(num>num_maior){
            
            num_maior=num;
        }
        if(num<num_menor){
            
            num_menor=num;
        }

        num=0;
    }

    printf("De 0-25: %d \n", sq1);

    printf("De 26-50: %d \n", sq2);

    printf("De 51-75: %d \n", sq3);

    printf("De 76-100: %d \n", sq4);
    
    printf("O maior numero digitado foi:%d \n",num_maior);
    
    printf("O menor numero digitado foi:%d \n",num_menor);

    return 0;

}