numeros = [1, 70, 16, 8]
print('numeros:',numeros)
for n in numeros:
    print('O dobro de ',n, 'é:')
    print(n * 2)