from math import sqrt, pi
#sqrt = raiz quadrada
print(sqrt(16))
print(pi)
