print('segundo dia como programador')

numero01 = 300
numero02 = 2

resultado = numero01 ** numero02
print('o resultado é:', resultado)