aluno1 = {'nome': 'Sara', 'turma': 'trilha1-2','conversador':'False'}
          #Key     Value 

aluno1['nome']
aluno1.get('nome')   