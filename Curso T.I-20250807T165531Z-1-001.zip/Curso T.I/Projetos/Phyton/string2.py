variavel01 = 'família'
variavel02 = 'dia'
variavel03 = 'Essa turma é top. python é 1'
print(variavel01[6])
#[] colchete serve para aparecer apenas a letra na coluna escolhida, 
# começando a contar de 0 em diante.
print(variavel03[-1])
#[-1] pega a ultima letra da palavra, [-2] a penultima e assim em diante.
print(variavel03[5:10])
# 5 start começar a imprimir da letra posição 5 e 10 a primeira letra que não quero pegar
