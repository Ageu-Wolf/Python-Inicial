print('APLICATIVO DE CONVERSÂO DOLAR X REAL')
print(39*'*')

cotacao = 5.12
valor_dolar = float((input('Insira o valor em dolar:')))

valor_real  = cotacao * valor_dolar

print('Cotação do dolar: R$', cotacao)
print('Valor do produto em dolar US$', valor_dolar)
print('Valor do produto em R$', valor_real)







