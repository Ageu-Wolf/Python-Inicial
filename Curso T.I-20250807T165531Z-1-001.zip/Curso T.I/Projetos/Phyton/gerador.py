ls1 = range(5,1000001)

for i in ls1:
    if i == 1:
        print(i,'elefante incomoda muito a gente')
    else:
        print(i, 'elefantes incomodam muito mais')