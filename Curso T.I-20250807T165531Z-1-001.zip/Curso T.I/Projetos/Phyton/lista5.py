ls = [2 , 8, 23]

ls.append('ultimo elemento')


for item in ls:
    print(2 * item)


