print('***********************************************************************')
print('                      App Internet Banking                             ')
print('                     Transferência Via PIX                             ')
print('***********************************************************************')

chave_pix = input('Digite a chave PIX:')
valor = input('Digite o valor: ')

print('O valor R$', valor, 'foi transferido para a chave', chave_pix)