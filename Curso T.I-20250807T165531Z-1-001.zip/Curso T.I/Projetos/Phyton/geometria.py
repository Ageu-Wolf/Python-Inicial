from math import pi
#funções

def calcular_area_quadrilatero(base, altura):
    return base * altura

def calcular_area_triangulo(base, altura):
    return (base * altura) / 2

def calcular_area_circulo(raio):
    return pi * (raio**2)


#programa principal
