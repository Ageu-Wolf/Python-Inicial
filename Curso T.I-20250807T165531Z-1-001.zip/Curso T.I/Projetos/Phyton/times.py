cor_camiseta = input('cor da camiseta:')

if cor_camiseta== 'vermelho ':
    print('inter')
elif cor_camiseta== 'Azul':
    print('Grêmio')
elif cor_camiseta=='verde':
    print('Juventude')