nome = input('Informe o seu nome:')

print(nome.upper())
print('O nome digitado possui', len(nome),'caracteres')

tamanho = len(nome)

print('O nome que foi digitado possui', tamanho,'caracteres')