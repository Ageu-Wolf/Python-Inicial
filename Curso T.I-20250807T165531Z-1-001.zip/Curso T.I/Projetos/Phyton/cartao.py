print (27*'*')
print ('            RSTI            ')

nome = input('Nome:')
setor = input('Setor:')
cargo = input('Cargo:')
email = input('email:')
telefone = input('Telefone:')

print(27*'=')
print('      RSTI TURMA TOP       ')

print(nome)
print('setor:', setor, 'cargo:', cargo )
print('E-mail:', email)
print('Telefone:', telefone )
print(27*'=')
