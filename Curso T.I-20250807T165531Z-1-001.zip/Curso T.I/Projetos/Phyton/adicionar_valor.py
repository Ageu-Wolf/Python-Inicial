from string import octdigits


#Adição
i = 10

i = i + 15 
#ou  
i += 15


#Subtração
b = 20

b = b -8
#ou
b -= 8