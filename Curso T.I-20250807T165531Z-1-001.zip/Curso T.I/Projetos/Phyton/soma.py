num1 = int(input('Digite N 1:'))
num2 = int(input('Digite N 2:'))

soma = (num1) + (num2)
subtracao = num1 - num2
multiplicação = num1 * num2
divisao = num1 / num2

print('Soma =', soma)
print('Subtracao', subtracao)
print('multiplicação', multiplicação)
print('Divisão', divisao)
