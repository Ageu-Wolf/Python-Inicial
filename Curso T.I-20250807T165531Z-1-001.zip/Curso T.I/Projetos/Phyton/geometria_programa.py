from geometria import calcular_area_quadrilatero, calcular_area_triangulo, calcular_area_circulo

#programa principal
resultado1 = calcular_area_quadrilatero(100, 30)
print(resultado1)

resultado2 = calcular_area_triangulo(20, 20)
print(resultado2)

resultado3 = round(calcular_area_circulo(5),2)
print(resultado3)






