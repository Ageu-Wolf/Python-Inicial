import os
from time import sleep

from libs.calculos import somar, subtrair, multiplicar, dividir, exponencial
from libs.menu import mostrar_menu, capturar_numeros

opcao = mostrar_menu()

while opcao != 6:
    nr_1, nr_2 = capturar_numeros()
    if opcao == 1:
        #Soma
        print(f'O resultado de {nr_1} + {nr_2}={somar(nr_1, nr_2)}')
    elif opcao == 2:
        #Subtração
        print(f'O resultado de {nr_1} - {nr_2}={subtrair(nr_1, nr_2)}')
    elif opcao == 3:
        #Multiplicação
        print(f'O resultado de {nr_1} X {nr_2}={multiplicar(nr_1, nr_2)}')
    elif opcao == 4:
        #Divisão
        print(f'O resultado de {nr_1} / {nr_2}={dividir(nr_1, nr_2)}')

    elif opcao == 5:
        #exponencial
        print(f'O resultado de {nr_1} elevado na ^{nr_2}={exponencial(nr_1, nr_2)}')
    else:
        """qualquer outro numero digitado 
            diferente de 1,2,3,4,5"""
        print('Opção Inválida!')

    sleep(4)
    os.system('cls')
    
    opcao = mostrar_menu()      

print('Vaza daqui rapaz!')