def somar(nr_1, nr_2):
    return nr_1 + nr_2

def subtrair(nr_1, nr_2):
    return nr_1 - nr_2

def multiplicar(nr_1, nr_2):
    return nr_1 * nr_2

def dividir(nr_1, nr_2):
    return nr_1 / nr_2

def exponencial(nr_1, nr_2):
    return nr_1 ** nr_2