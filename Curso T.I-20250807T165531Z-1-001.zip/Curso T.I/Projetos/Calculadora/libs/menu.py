def mostrar_menu():
    print('================ CALCULADORA ================')
    print('EScolha a opção desejada:')
    print('1) Somar')
    print('2) Subtrair')
    print('3) Multiplicar')
    print('4) Dividir')
    print('5) Exponencial')
    print('6) Sair')
    return int(input('opção: '))

def capturar_numeros():
    nr_1 = float(input('Primeiro Numero: '))
    nr_2 = float(input('Segundo Numero: '))
    return nr_1, nr_2